using System.Reflection;

// Version of the build. Bump this on every release; the zip in \download ships the matching exe.
[assembly: AssemblyTitle("Roblox MultiHub")]
[assembly: AssemblyProduct("Roblox MultiHub")]
[assembly: AssemblyCompany("Roblox MultiHub")]
[assembly: AssemblyVersion("1.4.2.0")]
[assembly: AssemblyFileVersion("1.4.2.0")]
[assembly: AssemblyInformationalVersion("1.4.2")]
